# PenTesShield - AI-Powered Penetration Testing Report Automation Platform

## 项目简介

PenTesShield 是一个基于多Agent协作架构的渗透测试报告自动化生成平台，通过四个专业Agent协同工作，从信息收集、漏洞扫描、验证利用到报告生成，提供完整的渗透测试工作流程自动化解决方案。

## 核心特性

### 1. 多Agent协作架构
- **ReconAgent**: 信息收集与攻击面发现
- **VulnScannerAgent**: 漏洞识别与风险评估
- **ExploitAgent**: 验证利用与概念证明
- **ReportGeneratorAgent**: 综合报告生成

### 2. 长链推理能力
每个Agent执行时记录完整的推理链条：
```
目标识别 → 服务发现 → 漏洞匹配 → 风险评估 → PoC生成 → 报告输出
```

### 3. 智能报告生成
- 自动汇总所有发现
- 生成执行摘要
- 优先级排序的修复建议
- Markdown/JSON多格式输出

## 快速开始

### 运行演示
```bash
python main.py demo
```

### 执行渗透测试
```bash
python main.py engage --target https://example.com
```

### 导出JSON报告
```bash
python main.py engage --target 192.168.1.1 --format json --output report.json
```

## 输出示例

```
# Penetration Testing Report
**Target:** https://demo.example.com
**Date:** 2024-01-15 10:30:00

## Executive Summary
OVERALL RISK LEVEL: CRITICAL
VULNERABILITIES FOUND:
- Critical: 1
- High: 2
- Medium: 1

## Reasoning Chain (Long-Chain Analysis)
### Step 1: ReconAgent
**Action:** Execute reconnaissance phase
**Inputs:** Target: https://demo.example.com
**Outputs:** IP addresses, domains, services discovered
**Decisions:** Discovering attack surface

### Step 2: VulnScannerAgent
**Action:** Execute vulnerability_scanner phase
**Inputs:** Target: https://demo.example.com, Attack surface: 15 entries
**Outputs:** Vulnerability candidates ranked by risk
**Decisions:** Identifying potential vulnerabilities

...
```

## 项目结构

```
penteshield/
├── src/
│   ├── core/
│   │   ├── agent.py           # 核心Agent基类
│   │   └── orchestrator.py    # 多Agent编排器
│   └── agents/
│       ├── recon_agent.py     # ReconAgent
│       ├── vuln_scanner_agent.py  # VulnScannerAgent
│       ├── exploit_agent.py   # ExploitAgent
│       └── report_generator_agent.py  # ReportGeneratorAgent
├── examples/                  # 示例文件
├── templates/                 # 报告模板
├── main.py                    # CLI入口
└── README.md
```

## 技术架构

### Agent执行流程
```
ReconAgent → VulnScannerAgent → ExploitAgent → ReportGeneratorAgent
    ↓              ↓                ↓               ↓
  攻击面发现    漏洞扫描        验证利用        报告生成
    ↓              ↓                ↓               ↓
    └──────────────┴────────────────┴───────────────┘
                          ↓
                   EngagementResult
                          ↓
                   综合报告输出
```

### 推理链示例
```json
{
  "step": 2,
  "agent": "VulnScannerAgent",
  "action": "Execute vulnerability_scanner phase",
  "inputs": ["Target: https://example.com", "Attack surface: 15 entries"],
  "outputs": ["Vulnerability candidates ranked by risk"],
  "decisions": ["Identifying potential vulnerabilities"],
  "next_steps": ["Verify vulnerabilities with exploitation agent"]
}
```

## License

MIT License
