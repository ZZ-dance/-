"""Core agent framework with base classes and interfaces for penetration testing"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class SeverityLevel(Enum):
    """Vulnerability severity levels following CVSS"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "informational"


class AgentType(Enum):
    """Available agent types in penetration testing workflow"""
    RECON = "reconnaissance"
    VULN_SCANNER = "vulnerability_scanner"
    EXPLOIT = "exploitation"
    REPORT_GENERATOR = "report_generator"


@dataclass
class Vulnerability:
    """Represents a discovered vulnerability"""
    vuln_id: str
    agent_type: AgentType
    severity: SeverityLevel
    title: str
    description: str
    target: str
    location: str
    cve_id: Optional[str] = None
    cvss_score: float = 0.0
    evidence: List[str] = field(default_factory=list)
    impact: str = ""
    remediation: str = ""
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "vuln_id": self.vuln_id,
            "agent_type": self.agent_type.value,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "target": self.target,
            "location": self.location,
            "cve_id": self.cve_id,
            "cvss_score": self.cvss_score,
            "evidence": self.evidence,
            "impact": self.impact,
            "remediation": self.remediation,
            "confidence": self.confidence,
            "metadata": self.metadata
        }


@dataclass
class Finding:
    """Represents a testing finding"""
    finding_id: str
    agent_type: AgentType
    category: str
    severity: SeverityLevel
    title: str
    description: str
    evidence_urls: List[str] = field(default_factory=list)
    screenshots: List[str] = field(default_factory=list)
    poc_steps: List[str] = field(default_factory=list)
    remediation_priority: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "finding_id": self.finding_id,
            "agent_type": self.agent_type.value,
            "category": self.category,
            "severity": self.severity.value,
            "title": self.title,
            "description": self.description,
            "evidence_urls": self.evidence_urls,
            "screenshots": self.screenshots,
            "poc_steps": self.poc_steps,
            "remediation_priority": self.remediation_priority
        }


@dataclass
class TestResult:
    """Complete result from an agent"""
    agent_type: AgentType
    target: str
    vulnerabilities: List[Vulnerability] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)
    metrics: Dict[str, float] = field(default_factory=dict)
    summary: str = ""
    reasoning_chain: List[str] = field(default_factory=list)
    timestamp: datetime = field(default_factory=datetime.now)

    def add_vulnerability(self, vuln: Vulnerability) -> None:
        self.vulnerabilities.append(vuln)
        logger.debug(f"Added vulnerability: {vuln.title} ({vuln.severity.value})")

    def add_finding(self, finding: Finding) -> None:
        self.findings.append(finding)

    def get_critical_vulns(self) -> List[Vulnerability]:
        return [v for v in self.vulnerabilities if v.severity == SeverityLevel.CRITICAL]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_type": self.agent_type.value,
            "target": self.target,
            "vulnerabilities": [v.to_dict() for v in self.vulnerabilities],
            "findings": [f.to_dict() for f in self.findings],
            "metrics": self.metrics,
            "summary": self.summary,
            "reasoning_chain": self.reasoning_chain,
            "timestamp": self.timestamp.isoformat()
        }


class BaseAgent(ABC):
    """Abstract base class for all penetration testing agents"""

    def __init__(self, name: str, agent_type: AgentType):
        self.name = name
        self.agent_type = agent_type
        self.is_initialized = False

    def initialize(self) -> None:
        """Initialize agent resources"""
        logger.info(f"Initializing {self.name} agent...")
        self._initialize()
        self.is_initialized = True

    @abstractmethod
    def _initialize(self) -> None:
        """Agent-specific initialization"""
        pass

    @abstractmethod
    async def execute(self, target: str, context: Optional[Dict] = None) -> TestResult:
        """Execute penetration testing task"""
        pass

    def can_handle(self, target: str) -> bool:
        """Check if this agent can handle the given target"""
        return True

    def get_priority(self) -> int:
        """Return execution priority (lower = higher priority)"""
        return 0
