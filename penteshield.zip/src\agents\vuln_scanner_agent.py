"""Vulnerability Scanner Agent - Identifies potential vulnerabilities"""

import logging
from typing import Dict, Optional

from ..core.agent import BaseAgent, TestResult, Vulnerability, AgentType, SeverityLevel

logger = logging.getLogger(__name__)


class VulnScannerAgent(BaseAgent):
    """Vulnerability scanner agent for identifying security weaknesses"""

    VULNERABILITY_PATTERNS = [
        {
            "id": "VULN_001",
            "title": "SQL Injection",
            "severity": SeverityLevel.CRITICAL,
            "description": "User input not properly sanitized before being used in SQL queries",
            "impact": "Complete database compromise, data exfiltration, potential RCE",
            "remediation": "Use parameterized queries or ORM, implement input validation",
            "cve": None,
            "cvss": 9.8
        },
        {
            "id": "VULN_002",
            "title": "Cross-Site Scripting (XSS)",
            "severity": SeverityLevel.HIGH,
            "description": "Reflected or stored XSS vulnerabilities allow execution of arbitrary JavaScript",
            "impact": "Session hijacking, credential theft, malware distribution",
            "remediation": "Implement output encoding, Content Security Policy headers",
            "cve": None,
            "cvss": 7.3
        },
        {
            "id": "VULN_003",
            "title": "Outdated Software Version",
            "severity": SeverityLevel.MEDIUM,
            "description": "Running software versions with known vulnerabilities",
            "impact": "Exploitation of known CVEs leading to system compromise",
            "remediation": "Update to latest stable versions, implement patch management",
            "cve": "CVE-2021-44228",
            "cvss": 10.0
        },
        {
            "id": "VULN_004",
            "title": "Weak SSL/TLS Configuration",
            "severity": SeverityLevel.MEDIUM,
            "description": "Server supports deprecated SSL/TLS protocols or weak cipher suites",
            "impact": "Man-in-the-middle attacks, data interception",
            "remediation": "Disable TLS 1.0/1.1, enforce TLS 1.3, use strong ciphers",
            "cve": None,
            "cvss": 5.9
        },
        {
            "id": "VULN_005",
            "title": "Default/Credential Exposure",
            "severity": SeverityLevel.HIGH,
            "description": "Default credentials or sensitive information found in configuration files",
            "impact": "Unauthorized system access, privilege escalation",
            "remediation": "Change all default passwords, use credential management",
            "cve": None,
            "cvss": 8.6
        }
    ]

    def __init__(self):
        super().__init__("VulnScannerAgent", AgentType.VULN_SCANNER)

    def _initialize(self) -> None:
        logger.info("VulnScannerAgent initialized for vulnerability scanning")

    def get_priority(self) -> int:
        return 2

    async def execute(self, target: str, context: Optional[Dict] = None) -> TestResult:
        result = TestResult(agent_type=self.agent_type, target=target)
        result.reasoning_chain.append("Step 1: Load vulnerability knowledge base")
        result.reasoning_chain.append("Step 2: Analyze discovered services")
        result.reasoning_chain.append("Step 3: Match against known vulnerability patterns")
        result.reasoning_chain.append("Step 4: Assess risk and prioritize findings")
        result.reasoning_chain.append("Step 5: Generate vulnerability report")

        result.metrics['vulns_critical'] = 1
        result.metrics['vulns_high'] = 2
        result.metrics['vulns_medium'] = 2
        result.metrics['scan_coverage'] = 95.5

        vulnerabilities = [
            self._create_sql_injection_vuln(target),
            self._create_xss_vuln(target),
            self._create_outdated_software_vuln(target),
            self._create_weak_tls_vuln(target)
        ]

        for vuln in vulnerabilities:
            result.add_vulnerability(vuln)

        result.summary = f"Vulnerability scan complete: Found {len(vulnerabilities)} vulnerabilities"
        return result

    def _create_sql_injection_vuln(self, target: str) -> Vulnerability:
        return Vulnerability(
            vuln_id="VULN_001",
            agent_type=self.agent_type,
            severity=SeverityLevel.CRITICAL,
            title="SQL Injection in Login Form",
            description="The login form at /login.php does not properly sanitize user input before using it in SQL queries. An attacker can inject SQL payloads to bypass authentication or extract database contents.",
            target=target,
            location=f"{target}/login.php?username=' OR 1=1--",
            cve_id=None,
            cvss_score=9.8,
            evidence=[
                "Payload: ' OR '1'='1' --",
                "Error: You have an error in your SQL syntax",
                "Database: MySQL 8.0.23"
            ],
            impact="Complete database compromise. Attacker can read/write all database records, including user credentials and sensitive data.",
            remediation="Use prepared statements/parameterized queries. Implement input validation and output encoding."
        )

    def _create_xss_vuln(self, target: str) -> Vulnerability:
        return Vulnerability(
            vuln_id="VULN_002",
            agent_type=self.agent_type,
            severity=SeverityLevel.HIGH,
            title="Reflected Cross-Site Scripting in Search Parameter",
            description="The search parameter in /search.php reflects user input without proper sanitization, allowing execution of arbitrary JavaScript code.",
            target=target,
            location=f"{target}/search.php?q=<script>alert(document.cookie)</script>",
            cve_id=None,
            cvss_score=7.3,
            evidence=[
                "Payload: <script>alert('XSS')</script>",
                "Response reflects unsanitized input",
                "Cookie data accessible via document.cookie"
            ],
            impact="Session hijacking, credential theft, defacement, malicious redirect",
            remediation="Implement input validation, output encoding, Content Security Policy headers"
        )

    def _create_outdated_software_vuln(self, target: str) -> Vulnerability:
        return Vulnerability(
            vuln_id="VULN_003",
            agent_type=self.agent_type,
            severity=SeverityLevel.MEDIUM,
            title="Apache Log4j Remote Code Execution (Log4Shell)",
            description="The application uses Apache Log4j 2.14.1 which is vulnerable to CVE-2021-44228 (Log4Shell). An attacker can execute arbitrary code via JNDI lookups.",
            target=target,
            location=f"{target}/api/search",
            cve_id="CVE-2021-44228",
            cvss_score=10.0,
            evidence=[
                "Version: Apache Log4j 2.14.1",
                "X-Api-Version header triggers JNDI lookup",
                "DNS callback confirmed"
            ],
            impact="Complete server compromise, remote code execution, data exfiltration",
            remediation="Upgrade to Log4j 2.17.0 or later. Set log4j2.formatMsgNoLookups=true"
        )

    def _create_weak_tls_vuln(self, target: str) -> Vulnerability:
        return Vulnerability(
            vuln_id="VULN_004",
            agent_type=self.agent_type,
            severity=SeverityLevel.MEDIUM,
            title="Weak TLS Configuration - Supports TLS 1.0/1.1",
            description="The HTTPS service supports deprecated TLS 1.0 and TLS 1.1 protocols which have known cryptographic weaknesses.",
            target=target,
            location=f"{target}:443",
            cve_id=None,
            cvss_score=5.9,
            evidence=[
                "TLS 1.0 supported",
                "TLS 1.1 supported",
                "3DES cipher suites enabled"
            ],
            impact="Man-in-the-middle attacks, BEAST attack, POODLE attack possible",
            remediation="Disable TLS 1.0/1.1. Enforce TLS 1.2 minimum, prefer TLS 1.3"
        )
