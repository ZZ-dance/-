"""CLI interface for PenTesShield - AI-Powered Penetration Testing Platform"""

import argparse
import asyncio
import json
import logging
import sys
from pathlib import Path
from datetime import datetime

from src.agents import (
    ReconAgent,
    VulnScannerAgent,
    ExploitAgent,
    ReportGeneratorAgent
)
from src.core.orchestrator import AgentOrchestrator

logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )


async def run_engagement(target: str, output_format: str = "markdown", output_file: str = None) -> None:
    """Execute a complete penetration testing engagement"""
    print(f"\n{'='*80}")
    print(f"PenTesShield - AI-Powered Penetration Testing Platform")
    print(f"{'='*80}\n")
    print(f"Starting engagement for target: {target}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

    agents = [
        ReconAgent(),
        VulnScannerAgent(),
        ExploitAgent(),
        ReportGeneratorAgent()
    ]

    for agent in agents:
        print(f"Initializing {agent.name}...")
        agent.initialize()
    print()

    orchestrator = AgentOrchestrator(agents)
    result = await orchestrator.orchestrate(target)

    print(f"\n{'='*80}")
    print("ENGAGEMENT RESULTS")
    print(f"{'='*80}\n")

    if output_format == "json":
        output = {
            "target": result.target,
            "start_time": result.start_time.isoformat(),
            "end_time": result.end_time.isoformat() if result.end_time else None,
            "total_vulnerabilities": result.total_vulnerabilities,
            "results": [r.to_dict() for r in result.results],
            "reasoning_chain": [step.to_dict() for step in result.reasoning_chain],
            "recommendations": result.recommendations
        }
        print(json.dumps(output, indent=2))
    else:
        print(result.to_report(format="markdown"))

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(result.to_report(format="markdown"))
        print(f"\n[+] Report saved to: {output_file}")

    print(f"\n{'='*80}")
    print("ENGAGEMENT COMPLETE")
    print(f"{'='*80}")
    print(f"Total Vulnerabilities Found: {result.total_vulnerabilities}")
    print(f"Total Findings: {sum(len(r.findings) for r in result.results)}")
    print(f"Reasoning Steps: {len(result.reasoning_chain)}")


async def demo_mode() -> None:
    """Run a demonstration engagement"""
    demo_target = "https://demo.example.com"
    print("\n[Demo Mode] Running demonstration penetration test...\n")
    await run_engagement(demo_target, "markdown")


def main():
    parser = argparse.ArgumentParser(
        description="PenTesShield - AI-Powered Penetration Testing Report Automation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py engage --target https://example.com
  python main.py engage --target 192.168.1.1 --format json --output report.json
  python main.py demo
  python main.py demo --format json
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    engage_parser = subparsers.add_parser('engage', help='Run penetration testing engagement')
    engage_parser.add_argument('--target', '-t', required=True, help='Target URL or IP address')
    engage_parser.add_argument(
        '--format', '-f',
        choices=['markdown', 'json'],
        default='markdown',
        help='Output format (default: markdown)'
    )
    engage_parser.add_argument(
        '--output', '-o',
        help='Output file path for the report'
    )
    engage_parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose output'
    )

    demo_parser = subparsers.add_parser('demo', help='Run demo engagement')
    demo_parser.add_argument(
        '--format', '-f',
        choices=['markdown', 'json'],
        default='markdown',
        help='Output format (default: markdown)'
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    if args.command == 'engage':
        setup_logging(args.verbose if hasattr(args, 'verbose') else False)
        asyncio.run(run_engagement(args.target, args.format, args.output))
    elif args.command == 'demo':
        setup_logging()
        asyncio.run(demo_mode())


if __name__ == "__main__":
    main()
